import tkinter as tk
import cv2
from PIL import Image, ImageTk

class CameraApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Bienvenido a Casa")
        self.geometry("400x400")

        # Crear un lienzo para mostrar la imagen de la cámara
        self.canvas = tk.Canvas(self, width=200, height=200)
        self.canvas.pack(pady=20)

        # Crear el botón para acceder a la cámara
        self.camera_button = tk.Button(self, text="Ingresar", command=self.open_camera)
        self.camera_button.pack(pady=10)

        # Inicializar la cámara
        self.cap = None
        self.camera_open = False

    def open_camera(self):
        if not self.camera_open:
            self.cap = cv2.VideoCapture(0)  # 0 es la cámara predeterminada
            self.camera_open = True
            self.show_camera()

    def show_camera(self):
        if self.camera_open:
            _, frame = self.cap.read()
            frame = cv2.flip(frame, 1)  # Voltear horizontalmente
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # Convertir a RGB

            # Mostrar la imagen en el lienzo
            img = Image.fromarray(frame)
            img = ImageTk.PhotoImage(image=img)
            self.canvas.create_image(0, 0, anchor=tk.NW, image=img)
            self.canvas.image = img  # Mantener una referencia para evitar la recolección de basura

            # Llamar al método después de un corto retraso para actualizar continuamente
            self.after(10, self.show_camera)

        else:
            # Abrir un cuadro de texto para ingresar una contraseña
            self.password_entry = tk.Entry(self, show="*")
            self.password_entry.pack(pady=10)
            self.password_button = tk.Button(self, text="Ingresar", command=self.check_password)
            self.password_button.pack()

    def check_password(self):
        password = self.password_entry.get()
        # Aquí puedes implementar la lógica para verificar la contraseña
        if password == "contraseña_correcta":
            print("Contraseña correcta")
        else:
            print("Contraseña incorrecta")

if __name__ == "__main__":
    app = CameraApp()
    app.mainloop()